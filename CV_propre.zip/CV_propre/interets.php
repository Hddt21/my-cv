<div id="interet">
                        <div>
                            <!--Interets -->
                            <h3 id="text11"><?php echo $int1['int1']?></h3>
                            <p id="p16"><?php echo $title['title']?></p>
                            <img id="img9" src="img/need.png" alt="">

                        </div>
                    </div>

                    <div class="langues">
                        <div>
                            <h3 id="text11"> <?php echo $lang['lang']?></h3>
                            <i id="p6"><?php echo $pratic['pratic']?></i>
                        </div>

                        <div class="lang">
                            <img id="img11" src="img/box.png">
                            <p id="text12"><?php echo $l1['l1']?></p>
                        </div>

                        <div class="lang">
                            <img id="img12" src="img/box.png">
                            <p id="text12"><?php echo $l2['l2']?></p>
                        </div>
                    </div>