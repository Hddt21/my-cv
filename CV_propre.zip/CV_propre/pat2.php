<div id="pat2">
                    <div id="inl">
                        <p id="p3"><?php echo $pat1['pat1']?><strong> <?php echo $lieu1['lieu1']?></strong></p>
                        <p id="p4"><?php echo $p1['p1']?></p>
                        <p id="p5"> <?php echo $work1['work1']?></p>
                        <hr id="lign1">
                    </div>
                    <p id="p3"><?php echo $pat2['pat2']?> <strong>  <?php echo $lieu2['lieu2']?></strong></p>
                    <p id="p4"><?php echo $p2['p2']?> </p>
                    <p id="p5"> <?php echo $work2['work2']?></p>
                    <hr id="lign1">
                    <div id="inl">
                        <p id="p3"><?php echo $pat3['pat3']?><strong> <?php echo $lieu3['lieu3']?></strong></p>
                        <p id="p4"><?php echo $p3['p3']?></p>
                        <p id="p5"> <?php echo $work3['work3']?> </p>
                        <hr id="lign1">
                    </div>
  </div>