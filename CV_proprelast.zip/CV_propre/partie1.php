<?php
class expe{
    public $part1;
    public $travail;

function __construct($part1,$travail)
{
    $this->part1=$part1;
    $this->travail=$travail;
}
function get_part1(){
    return $this->part1;
}
function get_travail(){
    return $this->travail;
}
}
$expe = new expe("Expérience professionelle","Expertise en entreprise");

?>


<div id="partie1">
                <!--Experiences -->
                <div id="entete"> <img src="img/bat.png" id="imag1" alt="expérience">
                    <p id="part1"><?php echo $expe->get_part1();?></p>
                    <p id="sous1"><em><sub><?php echo $expe->get_travail();?></sub></em></p>
                    <p id="part2"><img src="img/menu.png" alt="image"></p>
                </div>

            </div>



            