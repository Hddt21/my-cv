<?php
$cv_profile =[
    ['nom' => 'Henke DIBABO Darryl'],
    ['metier' => 'Developpeur Web /Admin BD'],
    ['naiss' => '13 Aout 2000'],
    ['origine'=> 'Originaire de Ouest cameroun'],
    ['situation' => 'Célibataire'],
    ['localisation' =>'Yassa entrée-Kaza'],
    ['ville' => 'Douala'],
    ['map'=> 'Map :4.053276? 9.765047'],
    ['telephone' =>'(+237) 694 715 623'],
    ['courrier' =>'Telegram, Whatsapp'],
    ['mail' =>'darryldibabo18@gmail.com'],
    ['plate' =>'Google+,Github'],
    ['projet'=> '+3 PROJETS'],
    ['contact'=> '+31 CONTACTS'],
    ['expe'=> ' EXP'],
];
$profile=$cv_profile [0];
$informat=$cv_profile [1];
$naiss=$cv_profile [2];
$originaire=$cv_profile [3];
$situe=$cv_profile [4];
$local=$cv_profile [5];
$ville=$cv_profile [6];
$map=$cv_profile[7];
$phone=$cv_profile [8];
$courrier=$cv_profile [9];
$mail=$cv_profile [10];
$plate=$cv_profile [11];
$projet=$cv_profile [12];
$contact=$cv_profile [13];
$expe=$cv_profile [14];

// description
$desc=[
   ['desc1'=>'Développement Front-End'],
   ['comp1'=>'HTML5, JavaFX, ...'],
   ['desc2'=>'Développement Java'],
   ['comp2'=>'Eclipse'],
   ['desc3'=>'Bases de données'],
   ['comp3'=>'MySql,Oracle 11g'],
   ['desc4'=>'UX Design'],
   ['comp4'=>'Photoshop'],
   ['desc5'=>'Outils d environnement'],
   ['comp5'=>'Visual Code, Git'],
   ['desc6'=>'Programmation'],
   ['comp6'=>'Arduino'],
];
$desc1=$desc[0];
$comp1=$desc [1];
$desc2=$desc[2];
$comp2=$desc [3];
$desc3=$desc [4];
$comp3=$desc [5];
$desc4=$desc [6];
$comp4=$desc [7];
$desc5=$desc[8];
$comp5=$desc [9];
$desc6=$desc[10];
$comp6=$desc [11];


// Experience
$partie1=[
    ['part1'=>'Expérience professionelle'],
    ['sous1'=>'Expertise en entreprise']
];
$exp=$partie1[0];
$travail=$partie1[1];

// competences
$patr2=[
    ['pat1'=>'Formation - '],
    ['lieu1'=>'Genius Center'],
    ['p1'=>'Juin 2019 - Aout 2019 '],
    ['work1'=>'Réalisation, montage d un robot Arduino'],
    ['pat2'=>'Stage Academique - '],
    ['lieu2'=>'Solidarité Technologique'],
    ['p2'=>'Juin 2020 -Septembre 2020 '],
    ['work2'=>'Recyclage des appareils élctronique'],
    ['pat3'=>'Stage Academique -'],
    ['lieu3'=>'Necta Global Consulting'],
    ['p3'=>'Juin 2021 - Aout 2021 http://nectags.com'],
    ['work3'=>'Réalisation de site web de présentation'],
];
$pat1=$patr2[0];
$lieu1=$patr2 [1];
$p1=$patr2 [2];
$work1=$patr2 [3];
$pat2=$patr2 [4];
$lieu2=$patr2 [5];
$p2=$patr2 [6];
$work2=$patr2 [7];
$pat3=$patr2 [8];
$lieu3=$patr2 [9];
$p3=$patr2 [10];
$work3=$patr2 [11];

// interets
$interets=[
    ['int1'=>'Point d interets'],
    ['title' =>'Simple passe temps pour se faire plaisir'],
    ['lang' =>'Langues'],
    ['pratic' =>'pratiquées en entreprise'],
    ['l1'=>'Français'],
    ['l2'=>'Anglais'],

];
$int1=$interets[0];
$title=$interets [1];
$lang=$interets [2];
$pratic=$interets [3];
$l1=$interets [4];
$l2=$interets [5];

// Cursus académique
$partie2=[
    ['curs' =>'Cursus académique'],
    ['clas1' =>'Classes préparatoires niveau 2 -'],
    ['ecole1' =>'IUC - Douala'],
    ['annee1' =>'2020/2021'],
    ['proj1' =>'Site Web de présentation de la société Necta Global Consulting'],
    ['clas2' =>'Classes préparatoires niveau 1 -'],
    ['ecole2' =>'IUC - Douala'],
    ['annee2' =>'2019/2020'],
    ['proj2' =>'Implementation du jeu de Shannon'],
    ['clas3' =>'Baccalaureat C - '],
    ['ecole3' =>'College Saint-Michel'],
    ['annee3' =>'2018/2019'],
    ['clas4' =>'PROBATOIRE C - '],
    ['ecole4' =>'College Saint-Michel'],
    ['annee4' =>'2017/2018'],
];
$curs=$partie2[0];
$clas1=$partie2 [1];
$ecole1=$partie2 [2];
$annee1=$partie2 [3];
$proj1=$partie2 [4];
$clas2=$partie2 [5];
$ecole2=$partie2 [6];
$annee2=$partie2 [7];
$proj2=$partie2 [8];
$clas3=$partie2 [9];
$ecole3=$partie2 [10];
$annee3=$partie2 [11];
$clas4=$partie2 [12];
$ecole4=$partie2 [13];
$annee4=$partie2 [14];



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="CV-darryl.css">
    <link rel="stylesheet" type="text/css" href="bootstap.css">


    <title>CV-Darryl</title>
</head>

<body>
    <div class="cv">
        <div class="cv_gauche_top">
            <!--Recherche -->
            <div id="recherche">
                <img id="men" src="img/men.png" alt="menu">
                <p id="text1">Besoin d'un chef de projet ?</p>
                <p id="img2"><img src="img/recherche.png" style="width: 20px; height:20px;" alt="menu "></p>
                <p id="barre">|</p>
                <p id="croix"><img src="img/croix.png" style="width: 20px; height:20px" alt="croix"> </p>
                <!--Recherche end-->

            </div>

            <img id="img3" src="img/moi.jpeg" alt="Mon image">
          
            <?php 
                require 'cv_profile.php';
            ?>

            <div class="cv_gauche_bottom">

            </div>

        </div>
        <div class="cv_droit">
        <?php 
                require 'partie1.php';
            ?>

            <div class="competency">
            <?php 
                require 'pat2.php';
            ?>
                
            </div>
            <!--end Experiences -->
            <div class="academy">
                <div class="autres">
                <?php 
                require 'interets.php';
                 ?>
             </div>
                <div class="ecole">
                    <!--End Interet -->
                    <?php 
                require 'partie2.php';
                 ?>
                </div>
            </div>
        </div>

    </div>

</body>

</html>