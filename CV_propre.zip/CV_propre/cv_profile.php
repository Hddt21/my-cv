<div class="cv_profile">
                <!--Description, Adress -->
                <p id="text2"><strong><?php echo $profile['nom'] ?></strong></p>
                <p id="metier"><sub><?php echo $informat['metier'] ?></sub></p>
                <img id="img4" src="img/ajouter.png" alt="ajouter">
                <p id="img5"><img src="img/cake.png" style="width: 35px; height:35px" alt="gateau"></p>
                <p id="text3"><?php echo $naiss['naiss']?><br><?php echo $originaire['origine']?><br><?php echo $situe['situation']?></p>
                <hr id="ligne">
                <p id="img6"><img src="img/loc.png" style="width: 35px; height:35px" alt="Localisation"></p>
                <p id="text4"><?php echo $local['localisation']?><br><?php echo $ville['ville']?> <br><?php echo $map['map']?></p>
                <hr id="ligne1">
                <p id="img7"><img src="img/tel.png" style="width: 35px; height:35px" alt="Localisation"></p>
                <p id="text6"><?php echo $phone['telephone']?><br><?php echo $courrier['courrier']?></p>
                <hr id="ligne2">
                <p id="img8"><img src="img/email.png" style="width: 35px; height:35px" alt="Localisation"></p>
                <p id="text7"><?php echo $mail['mail']?><br><?php echo $plate['plate']?></p>
                <br>
                <p id="text8">
                    <tia style="color:rgba(255, 255, 255, 0.856);"><?php echo $projet['projet']?></tia> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $contact['contact']?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    3 ANS D'EXP 
                </p>
                <!--End Description, Adress -->
                <hr id="caract3">
                <div id="desc">
                    <div id="text9">
                        <p id="case"><input type="checkbox" checked>&nbsp;&nbsp;&nbsp;&nbsp; <strong><?php echo $desc1['desc1']?></strong></p>
                        <p id="etoile"><span>*</span></p>
                    </div>
                    <p id="id1"><sub><?php echo $comp1['comp1']?></sub></p>
                    <p id="level1"><input style="width: 283px;" type="range" max=100 value=85></p>
                    <div>
                        <div id="text10">
                            <p id="case1"><input type="checkbox" checked>&nbsp;&nbsp;&nbsp;&nbsp; <strong><?php echo $desc2['desc2']?></strong></p>
                            <p id="etoile1"><span>*</span></p>
                        </div>
                        <p id="id1"><sub><?php echo $comp2['comp2']?></sub></p>
                        <p id="level1"><input style="width: 283px;" type="range" max=100 value=65></p>
                    </div>
                    <div>
                        <div id="text10">
                            <p id="case1"><input type="checkbox" checked>&nbsp;&nbsp;&nbsp;&nbsp; <strong><?php echo $desc3['desc3']?></strong></p>
                            <p id="etoile1"><span>*</span></p>
                        </div>
                        <p id="id1"><sub><?php echo $comp3['comp3']?><</sub></p>
                        <p id="level1"><input style="width: 283px;" type="range" max=100 value=58></p>
                    </div>
                    <div>
                        <div id="text10">
                            <p id="case1"><input type="checkbox" checked>&nbsp;&nbsp;&nbsp;&nbsp; <strong><?php echo $desc4['desc4']?></strong></p>
                            <p id="etoile1"><span>*</span></p>
                        </div>
                        <p id="id1"><sub><?php echo $comp4['comp4']?></sub></p>
                        <p id="level1"><input style="width: 283px;" type="range" max=100 value=70></p>
                    </div>
                    <div>
                        <div id="text10">
                            <p id="case1"><input type="checkbox" checked>&nbsp;&nbsp;&nbsp;&nbsp; <strong><?php echo $desc5['desc5']?></strong></p>
                            <p id="etoile1"><span>*</span></p>
                        </div>
                        <p id="id1"><sub><?php echo $comp5['comp5']?></sub></p>
                        <p id="level1"><input style="width: 283px;" type="range" max=100 value=74></p>
                    </div>
                    <div>
                        <div id="text10">
                            <p id="case1"><input type="checkbox" checked>&nbsp;&nbsp;&nbsp;&nbsp; <strong><?php echo $desc6['desc6']?></strong></p>
                            <p id="etoile1"><span>*</span></p>
                        </div>
                        <p id="id1"><sub><?php echo $comp6['comp6']?></sub></p>
                        <p id="level1"><input style="width: 283px;" type="range" max=100 value=45></p>
                    </div>

                </div>

            </div>