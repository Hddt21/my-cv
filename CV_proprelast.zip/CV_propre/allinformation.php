<?php

class info{
    public $nom ;
    public $metier ;
    function __construct($nom, $metier)
    {
        $this->nom= $nom;
        $this->metier = $metier;
    }
    function get_nom()
    {
        return $this->nom;
    }     
    function get_metier()
    {
    return $this->metier;    
    }
}

 // classes descriptions
class descriptions{
    public $naiss;
    public $origine;
    public $situe;
    public $lien;

    function __construct($naiss, $origine, $situe,$lien){
        $this->naiss= $naiss;
        $this->origine=$origine;
        $this->situe=$situe;
        $this->lien=$lien;
    }   
    function get_naiss(){
        return $this->naiss;
    }
    function get_origine(){
        return $this->origine;
    }
    function get_situe(){
        return $this->situe;
     }
     function get_lien(){
        return $this->lien;
     }
}


$info=new info("Henke DIBABO Darryl","Admin BD/DevOps");
echo $info->get_nom();
echo'<br>';
echo $info->get_metier();
echo'<br>';
$info1=new descriptions("Ne le 13 aout 2000","Originaire du Nkam","Celibataire","https://git.heroku.com/darrylhenke.git");
echo $info1->get_naiss();
echo'<br>';
echo $info1->get_origine();
echo'<br>';
echo $info1->get_situe();
echo'<br>';
echo $info1->get_lien();
echo'<br>';

?>