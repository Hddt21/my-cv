<div id="partie2">
                        <div id="bas1"> <img src="img/bat.png" id="imag1" alt="expérience">
                            <p id="part3">
                            </p>
                            <!--Cursus academique -->
                            <p id="entre"><?php echo $curs['curs']?></p>
                            <p id="sous2"><em><sub></sub></em></p>
                        </div>
                        <p id="prt2"><img src="img/menu.png" id="imag2" alt="image"></p>
                        <div class="competency">
                            <div class="border">
                                <div id="pat3">
                                    <p id="p3"><?php echo $clas1['clas1']?> <strong><?php echo $ecole1['ecole1']?></strong></p>
                                    <p id="p4"><?php echo $annee1['annee1']?></p>
                                    <p id="p5"> <?php echo $proj1['proj1']?></p>
                                    <hr id="lign1">
                                    <div id="inl">
                                        <p id="p3"><?php echo $clas2['clas2']?><strong><?php echo $ecole2['ecole2']?></strong></p>
                                        <p id="p4"><?php echo $annee2['annee2']?></p>
                                        <p id="p5"> <?php echo $proj2['proj2']?></p>
                                        <hr id="lign1">
                                    </div>
                                    <p id="p3"><?php echo $clas3['clas3']?> <strong><?php echo $ecole3['ecole3']?></strong></p>
                                    <p id="p4"><?php echo $annee3['annee3']?></p>
                                    <p id="p5"> </p>
                                    <hr id="lign1">
                                    <p id="p3"><?php echo $clas4['clas4']?> <strong><?php echo $ecole4['ecole4']?></strong></p>
                                    <p id="p4"><?php echo $annee4['annee4']?></p>
                                    <p id="p5"> </p>
                                    <hr id="lign1">
                                    <!--End Cursus academique -->
                                </div>
                            </div>
                        </div>
                    </div>