<div id="partie1">
                <!--Experiences -->
                <div id="entete"> <img src="img/bat.png" id="imag1" alt="expérience">
                    <p id="part1"><?php echo $exp['part1']?></p>
                    <p id="sous1"><em><sub><?php echo $travail['sous1']?></sub></em></p>
                    <p id="part2"><img src="img/menu.png" alt="image"></p>
                </div>

            </div>